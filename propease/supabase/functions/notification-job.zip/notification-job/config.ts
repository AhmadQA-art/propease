// Configuration for scheduled function
export const config = {
  scheduled: {
    // Run daily at 8 AM
    cron: "0 8 * * *"
  }
}
